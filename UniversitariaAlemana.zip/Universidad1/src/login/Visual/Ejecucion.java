package login.Visual;
public class Ejecucion {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Ventana obj = new Ventana();
		obj.setVisible(true);
	}

}
